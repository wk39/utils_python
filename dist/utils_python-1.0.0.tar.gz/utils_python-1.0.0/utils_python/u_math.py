

def bound_limit(x,lower,upper):
    ''' limit value between upper / lower'''

    return min(max(lower, x),upper)
